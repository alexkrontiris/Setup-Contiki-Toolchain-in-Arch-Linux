#ifndef IP_PROCESS_H
#define IP_PROCESS_H

uint16_t ip_process(unsigned char *buf, unsigned int len);

#endif /* IP_PROCESS_H */
